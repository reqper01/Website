import React, { useEffect, useMemo, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";

// -------------------------------------------------------------
// Luxe Palette & Typography (glass edition)
// -------------------------------------------------------------
const palette = {
  black: "#0A0A0B",
  gold: "#C8A04D", // muted regal gold
  deepRed: "#7A0A0A",
  offWhite: "#EFEAE2",
  gray: "#A8A297",
};

const fonts = {
  display: '"Playfair Display", serif',
  body: '"Plus Jakarta Sans", "Inter", system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, "Apple Color Emoji", "Segoe UI Emoji"',
};

const EASE = [0.22, 1, 0.36, 1];

// -------------------------------------------------------------
// Images (royalty‑free placeholders)
// -------------------------------------------------------------
const heroImages = [
  "/assets/hero1.jpg",
  "/assets/hero2.jpg",
  "/assets/hero3.jpg",
];

// 15 Mock Engagements
const engagementsDB = [
  { id: 1, title: "NDPS Defence Strategy Brief (4–5 kg cannabis)", category: "Criminal Defence / NDPS", tier: "Fixed-Fee Brief", image: "/assets/eng1.jpg", tags: ["NDPS", "Strategy", "Rapid"], summary: "Rapid merits map: seizure record audit, Sec. 42/50/57 compliance scan, Sec. 67 statement challenge matrix, FSL chain-of-custody vulnerabilities." },
  { id: 2, title: "Anticipatory Bail Playbook (482/438)", category: "Bail & Pre-Arrest", tier: "Expedited", image: "/assets/eng2.jpg", tags: ["Bail", "Quash", "Expedite"], summary: "Risk narrative, parity chart, timeline synthesis, counter to custodial interrogation claim, conditions proposal kit." },
  { id: 3, title: "White-Collar Internal Investigation", category: "White-Collar / Corporate", tier: "Retainer", image: "/assets/eng3.jpg", tags: ["Forensics", "Interviews", "Controls"], summary: "Interviews, document holds, email/IM review, board reporting, regulator-ready dossier (SFIO/ED readiness)." },
  { id: 4, title: "PMLA Defence Dossier", category: "White-Collar / PMLA", tier: "Fixed-Fee Brief", image: "/assets/eng4.jpg", tags: ["PMLA", "Attachment", "Bail"], summary: "Provisional attachment attack, proceeds-of-crime chain break, bail matrix, predicate-offence dependency analysis." },
  { id: 5, title: "High Court Criminal Appeal Kit", category: "Appellate Practice", tier: "Fixed-Fee", image: "/assets/eng5.jpg", tags: ["Appeal", "Strategy", "Grounds"], summary: "Grounds architecture (facts + law), error preservation, evidence misreadings table, relief strategy." },
  { id: 6, title: "482 CrPC Quash (498A/POCSO/Cyber variants)", category: "High Court Practice", tier: "Expedited", image: "/assets/eng6.jpg", tags: ["482", "Quash", "Jurisdiction"], summary: "Abuse-of-process argument map, jurisdictional defects, delay, settlement track, inconsistent prior statements." },
  { id: 7, title: "Cross-Examination Blueprint (498A / DV Defence)", category: "Trial Strategy", tier: "Toolkit", image: "/assets/eng7.jpg", tags: ["Cross", "Contradictions", "Impeach"], summary: "PW contradiction matrix, prior complaint delta map, medical/MLC hooks, 65B annexing protocol." },
  { id: 8, title: "Cybercrime Defence Pack (ITA/IPC/CrPC)", category: "Cybercrime", tier: "Fixed-Fee", image: "/assets/eng8.jpg", tags: ["ITA", "Forensics", "Logs"], summary: "Log chain map, device custody audit, hash ledger verification, expert affidavit templates." },
  { id: 9, title: "Commercial Suit — Rapid Response", category: "Commercial / Civil", tier: "Expedited", image: "/assets/eng9.jpg", tags: ["Interim", "Injunction", "Strategy"], summary: "Cause matrix, interim injunction pack (prima facie/balance/irreparable), damages computation skeleton." },
  { id: 10, title: "Arbitration — Emergency Relief (Sec. 9/17)", category: "Arbitration", tier: "Expedited", image: "/assets/eng10.jpg", tags: ["Arb", "Sec 9", "Emergency"], summary: "Asset-freeze brief, appointment challenge map, evidence bundle index, tribunal etiquette cheatsheet." },
  { id: 11, title: "Mediation Settlement Framework", category: "ADR / Mediation", tier: "Toolkit", image: "/assets/eng11.jpg", tags: ["Mediation", "Template", "Risk"], summary: "BATNA/WATNA map, payment plan clauses, confidentiality carve-outs, enforceability checklist." },
  { id: 12, title: "Consumer Commission Defence Kit", category: "Consumer / Regulatory", tier: "Fixed-Fee", image: "/assets/eng12.jpg", tags: ["Consumer", "Evidence", "Drafts"], summary: "Maintainability grid, limitation clock, deficiency rebuttals, annexures index, relief calibration." },
  { id: 13, title: "Police Liaison & Strategy Memo", category: "Criminal Defence / Strategy", tier: "Retainer", image: "/assets/eng13.jpg", tags: ["FIR", "Liaison", "Process"], summary: "Complaint drafting, FIR response templates, 160/41A compliance oversight, custody risk map." },
  { id: 14, title: "Case File War‑Room Audit", category: "Strategy / Audit", tier: "Fixed-Fee", image: "/assets/eng14.jpg", tags: ["Audit", "Gaps", "Next Steps"], summary: "File hygiene scan, contradictions ledger, exhibits sanity check, next-10-hearings roadmap." },
  { id: 15, title: "Corporate Compliance Heat‑Map", category: "Corporate Advisory", tier: "Retainer", image: "/assets/eng15.jpg", tags: ["Compliance", "Risk", "Dashboard"], summary: "Entity/regulatory inventory, risk scoring, remediation sprints plan, board reporting templates." },
];

const categories = ["All", ...Array.from(new Set(engagementsDB.map((e) => e.category)))];

// -------------------------------------------------------------
// Utilities & Micro‑components
// -------------------------------------------------------------
function Container({ children }) {
  return <div className="mx-auto w-full max-w-7xl px-5 sm:px-8 lg:px-10">{children}</div>;
}

function Glass({ children, className = "", style = {} }) {
  return (
    <div
      className={`backdrop-blur-xl rounded-3xl ${className}`}
      style={{
        background: "rgba(255,255,255,0.035)",
        border: `1px solid ${palette.gold}33`,
        WebkitBackdropFilter: "blur(18px)",
        boxShadow: "0 10px 40px rgba(0,0,0,0.35), inset 0 1px 0 rgba(255,255,255,0.04)",
        ...style,
      }}
    >
      {children}
    </div>
  );
}

function Pill({ children }) {
  return (
    <span
      style={{ background: `linear-gradient(90deg, ${palette.deepRed}22, ${palette.gold}22)`, border: `1px solid ${palette.gold}55`, color: palette.offWhite }}
      className="inline-flex items-center rounded-full px-3 py-1.5 text-[11px] tracking-wide"
    >
      {children}
    </span>
  );
}

function CTA({ label = "Book a Confidential Consultation", onClick, disabled }) {
  return (
    <motion.button
      onClick={onClick}
      whileHover={{ y: disabled ? 0 : -1, scale: disabled ? 1 : 1.01 }}
      whileTap={{ scale: disabled ? 1 : 0.99 }}
      transition={{ duration: 0.35, ease: EASE }}
      className={`group relative inline-flex items-center gap-3 rounded-2xl px-7 py-3.5 text-sm font-semibold transition-all ${disabled ? 'opacity-60 cursor-not-allowed' : ''}`}
      style={{ background: `linear-gradient(135deg, ${palette.deepRed}, ${palette.gold})`, color: palette.black, boxShadow: "0 10px 30px -10px rgba(200,160,77,.5), inset 0 0 0 1px rgba(0,0,0,.2)" }}
    >
      <span className="pointer-events-none absolute inset-0 overflow-hidden rounded-2xl">
        <motion.span
          initial={{ x: "-30%", opacity: 0 }}
          animate={{ x: "130%", opacity: [0, 0.7, 0] }}
          transition={{ repeat: Infinity, duration: 3, ease: "linear", repeatDelay: 1.4 }}
          className="absolute top-0 h-full w-1/3"
          style={{ background: "linear-gradient(90deg, rgba(255,255,255,0), rgba(255,255,255,.35), rgba(255,255,255,0))" }}
        />
      </span>
      <span className="translate-y-[0.5px]">{label}</span>
      <svg className="transition-transform group-hover:translate-x-1" width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M5 12h14M13 5l7 7-7 7" stroke="currentColor" strokeWidth="1.5" />
      </svg>
    </motion.button>
  );
}

// Mouse/touch‑responsive wrapper (tilt+parallax)
function Tilt({ children, max = 8 }) {
  const ref = useRef(null);
  const [t, setT] = useState({ rx: 0, ry: 0, tx: 0, ty: 0 });
  function compute(x, y, r) {
    const nx = x / r.width - 0.5;
    const ny = y / r.height - 0.5;
    return { rx: ny * -max, ry: nx * max, tx: nx * 6, ty: ny * 6 };
  }
  function onMove(e) {
    const r = ref.current?.getBoundingClientRect();
    if (!r) return;
    const x = e.clientX - r.left; const y = e.clientY - r.top;
    setT(compute(x, y, r));
  }
  function onTouch(e) {
    const r = ref.current?.getBoundingClientRect(); if (!r) return;
    const t0 = e.touches && e.touches[0]; if (!t0) return;
    setT(compute(t0.clientX - r.left, t0.clientY - r.top, r));
  }
  return (
    <div
      ref={ref}
      onMouseMove={onMove}
      onMouseLeave={() => setT({ rx: 0, ry: 0, tx: 0, ty: 0 })}
      onTouchMove={onTouch}
      onTouchEnd={() => setT({ rx: 0, ry: 0, tx: 0, ty: 0 })}
      style={{ transform: `perspective(900px) rotateX(${t.rx}deg) rotateY(${t.ry}deg) translate(${t.tx}px, ${t.ty}px)`, transition: "transform .35s cubic-bezier(.22,1,.36,1)", willChange: "transform" }}
    >
      {children}
    </div>
  );
}

// Subtle cursor glow (mouse & touch)
function CursorGlow() {
  const [p, setP] = useState({ x: -200, y: -200 });
  useEffect(() => {
    const move = (e) => {
      const t = e.touches?.[0];
      const x = t ? t.clientX : e.clientX; const y = t ? t.clientY : e.clientY;
      if (x == null || y == null) return; setP({ x, y });
    };
    window.addEventListener('pointermove', move, { passive: true });
    window.addEventListener('touchmove', move, { passive: true });
    return () => { window.removeEventListener('pointermove', move); window.removeEventListener('touchmove', move); };
  }, []);
  return (
    <div className="pointer-events-none fixed inset-0 z-30">
      <motion.div
        className="absolute h-[320px] w-[320px] rounded-full"
        animate={{ x: p.x - 160, y: p.y - 160 }}
        transition={{ type: "spring", stiffness: 120, damping: 18, mass: 0.25 }}
        style={{ background: `radial-gradient(140px 140px at center, ${palette.gold}25, rgba(0,0,0,0))`, filter: 'blur(18px)', mixBlendMode: 'screen' }}
      />
    </div>
  );
}

// Top scroll progress bar (page level)
function ScrollProgress() {
  const [p, setP] = useState(0);
  useEffect(() => {
    const onScroll = () => {
      const h = document.documentElement;
      const scrolled = h.scrollTop;
      const max = h.scrollHeight - h.clientHeight;
      setP(max > 0 ? (scrolled / max) * 100 : 0);
    };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);
  return (
    <div className="fixed left-0 top-0 z-[60] h-[3px] w-full bg-transparent">
      <div className="h-full" style={{ width: `${p}%`, background: `linear-gradient(90deg, ${palette.gold}, ${palette.deepRed})`, boxShadow: `0 0 12px ${palette.gold}55` }} />
    </div>
  );
}

function Card({ item, onQuickView }) {
  return (
    <Tilt max={7}>
      <Glass className="overflow-hidden">
        <div className="relative aspect-[16/10] w-full overflow-hidden rounded-3xl">
          <img src={item.image} alt={item.title} className="h-full w-full object-cover transition-transform duration-700 hover:scale-105" />
          <div className="absolute right-3 top-3 flex gap-2"><Pill>{item.tier}</Pill></div>
        </div>
        <div className="space-y-4 p-6 md:p-7">
          <h3 className="text-xl md:text-2xl font-semibold tracking-tight" style={{ color: palette.offWhite, fontFamily: fonts.display }}>{item.title}</h3>
          <div className="flex flex-wrap gap-2"><Pill>{item.category}</Pill>{item.tags.map((t) => (<Pill key={t}>{t}</Pill>))}</div>
          <div className="pt-2"><button onClick={() => onQuickView(item)} className="rounded-xl px-4 py-2 text-sm" style={{ border: `1px solid ${palette.gold}66`, color: palette.offWhite, background: `rgba(0,0,0,.35)` }}>Quick View</button></div>
        </div>
      </Glass>
    </Tilt>
  );
}

// -------------------------------------------------------------
// SEO (basic)
// -------------------------------------------------------------
function SEO() {
  useEffect(() => {
    document.title = "APM Legal — Boutique Criminal Defence & Corporate Litigation";
    const metaDescription = document.querySelector('meta[name="description"]');
    if (!metaDescription) {
      const m = document.createElement("meta");
      m.name = "description";
      m.content = "APM Legal is a boutique criminal defence and corporate litigation practice delivering high-stakes strategy across NDPS, white-collar, PMLA, and commercial disputes.";
      document.head.appendChild(m);
    }
    const ogTitle = document.querySelector('meta[property="og:title"]') || (() => { const m = document.createElement("meta"); m.setAttribute("property", "og:title"); document.head.appendChild(m); return m; })();
    ogTitle.setAttribute("content", document.title);
    const ogType = document.querySelector('meta[property="og:type"]') || (() => { const m = document.createElement("meta"); m.setAttribute("property", "og:type"); document.head.appendChild(m); return m; })();
    ogType.setAttribute("content", "website");

    const ld = document.createElement("script");
    ld.type = "application/ld+json";
    ld.innerHTML = JSON.stringify({ "@context": "https://schema.org", "@type": "LegalService", name: "APM Legal Services LLP", url: "https://example.com", areaServed: "India", address: { "@type": "PostalAddress", addressLocality: "Lucknow", addressCountry: "IN" }, legalName: "APM Legal Services LLP", sameAs: ["https://www.linkedin.com/", "https://maps.google.com"], image: heroImages[0], description: "Boutique criminal defence & corporate litigation across NDPS, white-collar, PMLA, arbitration, and commercial disputes.", hasOfferCatalog: { "@type": "OfferCatalog", name: "Engagements", itemListElement: engagementsDB.slice(0, 10).map((e) => ({ "@type": "Offer", name: e.title, category: e.category, description: e.summary })) } });
    document.head.appendChild(ld);
    return () => { if (ld && ld.parentNode) ld.parentNode.removeChild(ld); };
  }, []);
  return null;
}

// -------------------------------------------------------------
// Pages
// -------------------------------------------------------------
function Home({ navigate, onCTAClick }) {
  const [bgIdx, setBgIdx] = useState(0);
  const [parallax, setParallax] = useState({ x: 0, y: 0 });
  const [lens, setLens] = useState({ x: 0, y: 0 });
  useEffect(() => { const t = setInterval(() => setBgIdx((i) => (i + 1) % heroImages.length), 7000); return () => clearInterval(t); }, []);

  function onHeroMove(e) {
    const r = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - r.left) / r.width - 0.5) * 10;
    const y = ((e.clientY - r.top) / r.height - 0.5) * 10;
    setParallax({ x, y }); setLens({ x: e.clientX - r.left, y: e.clientY - r.top });
  }
  function onHeroTouch(e) {
    const t0 = e.touches?.[0]; if (!t0) return; const r = e.currentTarget.getBoundingClientRect();
    const x = ((t0.clientX - r.left) / r.width - 0.5) * 10; const y = ((t0.clientY - r.top) / r.height - 0.5) * 10;
    setParallax({ x, y }); setLens({ x: t0.clientX - r.left, y: t0.clientY - r.top });
  }

  return (
    <div className="relative isolate">
      {/* Typography */}
      <link rel="preconnect" href="https://fonts.googleapis.com" />
      <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
      <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700&family=Playfair+Display:wght@500;600;700&display=swap" rel="stylesheet" />

      {/* Hero */}
      <div className="relative min-h-[82vh] overflow-hidden" onMouseMove={onHeroMove} onTouchMove={onHeroTouch}>
        <motion.img src={heroImages[bgIdx]} alt="APM Legal — Hero" className="absolute inset-0 h-full w-full object-cover" animate={{ scale: 1.06, x: parallax.x, y: parallax.y }} transition={{ type: "spring", stiffness: 60, damping: 18 }} />
        {/* Cursor/touch‑followed light sheen */}
        <motion.div className="pointer-events-none absolute inset-0" style={{ background: `radial-gradient(280px 220px at ${lens.x}px ${lens.y}px, rgba(255,255,255,0.06), rgba(255,255,255,0))` }} />
        {/* Vignette */}
        <div className="absolute inset-0" style={{ background: "radial-gradient(80% 60% at 50% 30%, rgba(10,10,11,0.05) 0%, rgba(10,10,11,0.85) 60%, #0A0A0B 100%)" }} />
        <Container>
          <div className="relative z-10 flex min-h-[82vh] flex-col items-start justify-center py-24">
            <Glass className="max-w-3xl p-8 md:p-10">
              <motion.h1 initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, ease: EASE }} className="text-5xl md:text-7xl leading-[1.1] tracking-tight" style={{ color: palette.offWhite, fontFamily: fonts.display }}>Boutique Criminal Defence & Corporate Litigation</motion.h1>
              <motion.p initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, ease: EASE, delay: 0.15 }} className="mt-6 text-lg md:text-xl leading-relaxed md:leading-loose" style={{ color: palette.gray, fontFamily: fonts.body }}>Uncompromising strategy for NDPS, white-collar, PMLA, and complex commercial disputes. Precision, speed, and courtroom craft.</motion.p>
              <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, ease: EASE, delay: 0.3 }} className="mt-10 flex flex-wrap items-center gap-4">
                <CTA onClick={onCTAClick} />
                <button onClick={() => navigate("engagements")} className="rounded-2xl px-6 py-3 text-sm font-semibold" style={{ border: `1px solid ${palette.gold}55`, color: palette.offWhite, background: `rgba(0,0,0,.35)` }}>View Practice Areas</button>
              </motion.div>
              <div className="mt-10 flex flex-wrap gap-3"><Pill>NDPS & PMLA</Pill><Pill>White-Collar & Compliance</Pill><Pill>Commercial & Arbitration</Pill><Pill>High Court Practice</Pill></div>
            </Glass>
          </div>
        </Container>
      </div>

      {/* Areas of Practice */}
      <section className="py-16 md:py-20">
        <Container>
          <h2 className="mb-8 text-3xl md:text-4xl tracking-tight" style={{ color: palette.offWhite, fontFamily: fonts.display }}>Our Areas of Practice</h2>
          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
            {[
              { t: 'Criminal Defence / NDPS', d: 'Seizure record audits, Sec. 42/50/57 compliance, custody & bail strategy.' },
              { t: 'White‑Collar / PMLA', d: 'Attachment challenges, proceeds‑of‑crime analysis, investigation defence.' },
              { t: 'Commercial & Arbitration', d: 'Injunctions, Sec. 9/17 emergency relief, damages & enforcement.' },
              { t: 'High Court Practice (482/438)', d: 'Quash petitions, anticipatory bail, appellate strategy.' },
            ].map((x) => (
              <Glass key={x.t} className="p-7 md:p-8">
                <h3 className="text-xl md:text-2xl" style={{ color: palette.offWhite, fontFamily: fonts.display }}>{x.t}</h3>
                <p className="mt-3 text-sm md:text-base leading-relaxed" style={{ color: palette.gray }}>{x.d}</p>
                <div className="mt-5"><button onClick={() => navigate('engagements')} className="rounded-xl px-4 py-2 text-sm" style={{ border: `1px solid ${palette.gold}55`, color: palette.offWhite }}>Explore</button></div>
              </Glass>
            ))}
          </div>
        </Container>
      </section>

      {/* Testimonials */}
      <section className="py-16 md:py-20">
        <Container>
          <h2 className="mb-8 text-3xl md:text-4xl tracking-tight" style={{ color: palette.offWhite, fontFamily: fonts.display }}>Why clients retain us</h2>
          <div className="grid gap-8 md:grid-cols-3">
            {[
              '“Clarity under pressure. Their filings and courtroom craft changed the trajectory of our case.” — Client, Manufacturing (placeholder)',
              '“Rapid, surgical strategy on tight timelines. Clear risk maps and measurable outcomes.” — GC, Tech (placeholder)',
              '“They don’t waste words. They win key hearings.” — Founder, Healthcare (placeholder)'
            ].map((q, i) => (
              <Glass key={i} className="p-7 md:p-8"><p className="text-sm md:text-base leading-relaxed" style={{ color: palette.offWhite }}>{q}</p></Glass>
            ))}
          </div>
          <div className="mt-10"><CTA onClick={() => navigate('contact')} /></div>
        </Container>
      </section>

      {/* Get Started CTA */}
      <section className="pb-16 md:pb-24">
        <Container>
          <Glass className="p-8 md:p-10 text-center">
            <h3 className="text-2xl md:text-3xl tracking-tight" style={{ color: palette.offWhite, fontFamily: fonts.display }}>Safeguard your most critical matters.</h3>
            <p className="mx-auto mt-3 max-w-2xl text-sm md:text-base leading-relaxed" style={{ color: palette.gray }}>Contact us to see how we can help.</p>
            <div className="mt-6"><CTA onClick={() => navigate('contact')} /></div>
          </Glass>
        </Container>
      </section>
    </div>
  );
}

function Engagements({ onQuickView }) {
  const [active, setActive] = useState("All");
  const filtered = useMemo(() => (active === "All" ? engagementsDB : engagementsDB.filter((e) => e.category === active)), [active]);
  return (
    <section className="py-16 md:py-20">
      <Container>
        <div className="mb-8 flex flex-wrap items-center justify-between gap-4">
          <h2 className="text-3xl md:text-4xl tracking-tight" style={{ color: palette.offWhite, fontFamily: fonts.display }}>Practice Areas & Toolkits</h2>
          <div className="flex flex-wrap gap-2">
            {categories.map((c) => (
              <motion.button key={c} onClick={() => setActive(c)} whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.985 }} transition={{ duration: 0.35, ease: EASE }} className={`rounded-full px-4 py-2 text-sm transition-all ${active === c ? "" : "opacity-80"}`} style={{ border: `1px solid ${palette.gold}${active === c ? "" : "55"}`, background: active === c ? `${palette.gold}` : `rgba(0,0,0,.35)`, color: active === c ? palette.black : palette.offWhite }}>{c}</motion.button>
            ))}
          </div>
        </div>
        <motion.div layout className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((item) => (<Card key={item.id} item={item} onQuickView={onQuickView} />))}
        </motion.div>
      </Container>
    </section>
  );
}

function Team() {
  const team = [
    { name: "Rituraj Mishra", role: "Criminal Defence & Strategy", img: "/assets/team1.jpg" },
    { name: "Senior Counsel (Of-Counsel)", role: "High Court & Appellate", img: "/assets/team2.jpg" },
    { name: "Corporate Lead", role: "White-Collar & Compliance", img: "/assets/team3.jpg" },
  ];
  return (
    <section className="py-16 md:py-20">
      <Container>
        <h2 className="mb-8 text-3xl md:text-4xl tracking-tight" style={{ color: palette.offWhite, fontFamily: fonts.display }}>Team</h2>
        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {team.map((m) => (
            <Tilt key={m.name} max={6}>
              <Glass className="overflow-hidden">
                <div className="aspect-[4/3] w-full overflow-hidden rounded-3xl">
                  <img src={m.img} alt={m.name} className="h-full w-full object-cover transition-transform duration-700 hover:scale-105" />
                </div>
                <div className="p-6 md:p-7">
                  <h3 className="text-xl md:text-2xl" style={{ color: palette.offWhite, fontFamily: fonts.display }}>{m.name}</h3>
                  <p className="mt-2 text-sm md:text-base" style={{ color: palette.gray }}>{m.role}</p>
                </div>
              </Glass>
            </Tilt>
          ))}
        </div>
      </Container>
    </section>
  );
}

// -------------------------------------------------------------
// Appointment (container restyled to glass)
// -------------------------------------------------------------
function Contact({ onSubmit }) {
  const [step, setStep] = useState(1);
  const [form, setForm] = useState({ name: "", email: "", phone: "", category: "Criminal Defence / NDPS", preferred: "", notes: "" });
  function update(k, v) { setForm((f) => ({ ...f, [k]: v })); }
  function submit() { setStep(3); onSubmit?.(form); }
  return (
    <section className="py-16 md:py-20">
      <Container>
        <h2 className="mb-8 text-3xl md:text-4xl tracking-tight" style={{ color: palette.offWhite, fontFamily: fonts.display }}>Book a Confidential Consultation</h2>
        <Glass className="mx-auto max-w-3xl p-6 md:p-8">
          <div className="mb-8 grid grid-cols-3 gap-2 text-center text-xs">
            {["Details", "Matter", "Confirm"].map((s, i) => (<div key={s} className={`rounded-full px-3 py-2 ${step >= i + 1 ? "opacity-100" : "opacity-50"}`} style={{ border: `1px solid ${palette.gold}55`, color: palette.offWhite }}>{i + 1}. {s}</div>))}
          </div>
          {step === 1 && (
            <div className="space-y-5">
              <Field label="Name"><input value={form.name} onChange={(e) => update("name", e.target.value)} className="w-full rounded-xl bg-black/30 px-4 py-3 text-sm" style={{ border: `1px solid ${palette.gold}44`, color: palette.offWhite }} placeholder="Your full name" /></Field>
              <div className="grid gap-5 sm:grid-cols-2">
                <Field label="Email"><input value={form.email} onChange={(e) => update("email", e.target.value)} className="w-full rounded-xl bg-black/30 px-4 py-3 text-sm" style={{ border: `1px solid ${palette.gold}44`, color: palette.offWhite }} placeholder="you@example.com" /></Field>
                <Field label="Phone"><input value={form.phone} onChange={(e) => update("phone", e.target.value)} className="w-full rounded-xl bg-black/30 px-4 py-3 text-sm" style={{ border: `1px solid ${palette.gold}44`, color: palette.offWhite }} placeholder="+91 …" /></Field>
              </div>
              <div className="flex justify-end"><CTA label="Next: Matter" onClick={() => setStep(2)} /></div>
            </div>
          )}
          {step === 2 && (
            <div className="space-y-5">
              <Field label="Matter Type"><select value={form.category} onChange={(e) => update("category", e.target.value)} className="w-full rounded-xl bg-black/30 px-4 py-3 text-sm" style={{ border: `1px solid ${palette.gold}44`, color: palette.offWhite }}>{categories.filter((c) => c !== "All").map((c) => (<option key={c} value={c} className="bg-black">{c}</option>))}</select></Field>
              <Field label="Preferred Date/Time"><input value={form.preferred} onChange={(e) => update("preferred", e.target.value)} className="w-full rounded-xl bg-black/30 px-4 py-3 text-sm" style={{ border: `1px solid ${palette.gold}44`, color: palette.offWhite }} placeholder="e.g., 20 Aug, 4:30 PM (IST)" /></Field>
              <Field label="Notes"><textarea value={form.notes} onChange={(e) => update("notes", e.target.value)} rows={4} className="w-full rounded-xl bg-black/30 px-4 py-3 text-sm" style={{ border: `1px solid ${palette.gold}44`, color: palette.offWhite }} placeholder="Briefly describe the matter (confidential)"></textarea></Field>
              <div className="flex items-center justify-between"><button onClick={() => setStep(1)} className="rounded-2xl px-6 py-3 text-sm font-semibold" style={{ border: `1px solid ${palette.gold}55`, color: palette.offWhite, background: `rgba(0,0,0,.3)` }}>Back</button><CTA label="Review & Confirm" onClick={() => setStep(3)} /></div>
            </div>
          )}
          {step === 3 && (
            <div className="space-y-6">
              <h3 className="text-xl md:text-2xl" style={{ color: palette.offWhite, fontFamily: fonts.display }}>Confirmation</h3>
              <div className="grid gap-4 text-sm" style={{ color: palette.offWhite }}>
                <Row k="Name" v={form.name || "—"} />
                <Row k="Email" v={form.email || "—"} />
                <Row k="Phone" v={form.phone || "—"} />
                <Row k="Matter Type" v={form.category} />
                <Row k="Preferred" v={form.preferred || "—"} />
                <Row k="Notes" v={form.notes || "—"} />
              </div>
              <div className="flex items-center justify-end gap-3"><button onClick={() => setStep(2)} className="rounded-2xl px-6 py-3 text-sm font-semibold" style={{ border: `1px solid ${palette.gold}55`, color: palette.offWhite, background: `rgba(0,0,0,.3)` }}>Back</button><CTA label="Submit Request" onClick={submit} /></div>
              <p className="text-xs" style={{ color: palette.gray }}>By submitting, you consent to confidential processing for conflict checks and scheduling.</p>
            </div>
          )}
        </Glass>
      </Container>
    </section>
  );
}

function Field({ label, children }) { return (<label className="block space-y-2"><span className="text-[11px] uppercase tracking-[0.18em]" style={{ color: palette.gray }}>{label}</span>{children}</label>); }
function Row({ k, v }) { return (<div className="grid grid-cols-3 items-start gap-6"><div className="text-gray-400">{k}</div><div className="col-span-2" style={{ color: palette.offWhite }}>{v}</div></div>); }

// -------------------------------------------------------------
// Quick View Modal
// -------------------------------------------------------------
function Modal({ open, onClose, item, onPrimary }) {
  if (!open) return null;
  return (
    <AnimatePresence>
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: "rgba(0,0,0,0.6)" }} onClick={onClose}>
        <motion.div initial={{ scale: 0.98, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.98, opacity: 0 }} transition={{ type: "spring", stiffness: 210, damping: 20 }} className="w-full max-w-3xl overflow-hidden rounded-3xl" style={{ background: `rgba(255,255,255,0.035)`, border: `1px solid ${palette.gold}44`, WebkitBackdropFilter: 'blur(18px)', backdropFilter: 'blur(18px)' }} onClick={(e) => e.stopPropagation()}>
          {item && (
            <div className="grid gap-0 md:grid-cols-2">
              <div className="relative h-56 md:h-full"><img src={item.image} alt={item.title} className="absolute inset-0 h-full w-full object-cover" /></div>
              <div className="space-y-4 p-6 md:p-7">
                <Pill>{item.category}</Pill>
                <h3 className="text-2xl" style={{ color: palette.offWhite, fontFamily: fonts.display }}>{item.title}</h3>
                <p className="text-sm leading-relaxed" style={{ color: palette.gray }}>{item.summary}</p>
                <div className="flex flex-wrap gap-2">{item.tags.map((t) => <Pill key={t}>{t}</Pill>)}</div>
                <div className="pt-2"><CTA label="Request Engagement" onClick={onPrimary} /></div>
              </div>
            </div>
          )}
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}

// -------------------------------------------------------------
// Terms & Conditions Gate (first‑visit)
// -------------------------------------------------------------
function TermsGate() {
  const [show, setShow] = useState(false);
  const [checked, setChecked] = useState(false);
  const [progress, setProgress] = useState(0);
  const boxRef = useRef(null);
  useEffect(() => {
    try { setShow(localStorage.getItem('apm_terms_v1_accepted') !== 'yes'); } catch { setShow(true); }
  }, []);
  useEffect(() => {
    const el = boxRef.current; if (!el) return;
    const onScroll = () => { const p = el.scrollTop / (el.scrollHeight - el.clientHeight); setProgress(Math.max(0, Math.min(1, p))); };
    el.addEventListener('scroll', onScroll, { passive: true }); onScroll();
    return () => el.removeEventListener('scroll', onScroll);
  }, [boxRef, show]);
  if (!show) return null;
  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center p-4" style={{ background: "rgba(0,0,0,.75)" }}>
      <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ duration: 0.5, ease: EASE }} className="relative w-full max-w-2xl overflow-hidden rounded-3xl" style={{ border: `1px solid ${palette.gold}55`, background: `rgba(255,255,255,0.04)`, WebkitBackdropFilter: 'blur(18px)', backdropFilter: 'blur(18px)' }}>
        {/* progress bar for terms box */}
        <div className="absolute left-0 top-0 h-1 w-full bg-black/30"><div className="h-full" style={{ width: `${progress * 100}%`, background: palette.gold }} /></div>
        <div className="p-6 md:p-8">
          <h2 className="text-2xl md:text-3xl tracking-tight" style={{ color: palette.offWhite, fontFamily: fonts.display }}>Terms & Conditions</h2>
          <p className="mt-1 text-xs" style={{ color: palette.gray }}>Please review and accept to proceed to the site.</p>
          <div ref={boxRef} className="mt-4 max-h-[50vh] overflow-y-auto pr-2 text-sm leading-relaxed" style={{ color: palette.offWhite }}>
            <p><strong>Confidentiality.</strong> Information shared via this website or contact form is treated as confidential for conflict checks and scheduling, but does not create a client–advocate relationship until a formal engagement is executed.</p>
            <p className="mt-3"><strong>No Legal Advice.</strong> Content is for informational purposes only and should not be construed as legal advice.</p>
            <p className="mt-3"><strong>Accuracy.</strong> While we strive for accuracy, we do not guarantee completeness; outcomes depend on facts and law.</p>
            <p className="mt-3"><strong>Privacy.</strong> We process limited personal data for scheduling and communication. By proceeding, you consent to this processing.</p>
            <p className="mt-3"><strong>Jurisdiction.</strong> Disputes are subject to competent courts within India unless agreed otherwise.</p>
            <p className="mt-3"><strong>Updates.</strong> Terms may be updated; continued use constitutes acceptance.</p>
            <p className="mt-3">By ticking the box below and clicking <em>Accept & Enter</em>, you agree to these terms.</p>
            <div className="h-8" />
          </div>
          <label className="mt-4 flex items-center gap-2 text-xs" style={{ color: palette.gray }}>
            <input type="checkbox" checked={checked} onChange={(e) => setChecked(e.target.checked)} /> I have read and accept the Terms & Conditions.
          </label>
          <div className="mt-5 flex items-center justify-end gap-3">
            <button onClick={() => window.open('https://www.google.com', '_self')} className="rounded-2xl px-4 py-2 text-sm" style={{ border: `1px solid ${palette.gold}44`, color: palette.offWhite }}>Decline</button>
            <CTA label="Accept & Enter" onClick={() => { try { localStorage.setItem('apm_terms_v1_accepted', 'yes'); } catch {} setShow(false); }} disabled={!checked || progress < 0.98} />
          </div>
          <p className="mt-3 text-[11px]" style={{ color: palette.gray }}>Tip: The accept button unlocks after you scroll to the bottom of the terms and check the box.</p>
        </div>
      </motion.div>
    </div>
  );
}

// -------------------------------------------------------------
// Navigation & Footer
// -------------------------------------------------------------
function Nav({ route, navigate }) {
  const items = [ { k: "home", label: "Home" }, { k: "engagements", label: "Practice Areas" }, { k: "team", label: "Team" }, { k: "contact", label: "Contact" } ];
  return (
    <div className="sticky top-0 z-40 backdrop-blur-xl" style={{ background: "rgba(10,10,11,0.65)", borderBottom: `1px solid ${palette.gold}22` }}>
      <Container>
        <div className="flex h-20 items-center justify-between">
          <div className="flex items-center gap-3">
            <img src="/assets/logo.svg" alt="APM Legal" className="h-10 w-10 rounded-full" />
            <div>
              <div className="text-sm tracking-[0.25em]" style={{ color: palette.gray }}>APM LEGAL</div>
              <div className="-mt-1 text-xs" style={{ color: palette.gold }}>Criminal Defence • Corporate Litigation</div>
            </div>
          </div>
          <div className="hidden gap-2 md:flex">
            {items.map((it) => (
              <button key={it.k} onClick={() => navigate(it.k)} className={`rounded-full px-5 py-2.5 text-sm ${route === it.k ? "" : "opacity-85"}`} style={{ color: route === it.k ? palette.black : palette.offWhite, background: route === it.k ? palette.gold : "rgba(255,255,255,0.06)", border: `1px solid ${palette.gold}44` }}>{it.label}</button>
            ))}
          </div>
          <div className="md:hidden"><button onClick={() => navigate(route === "menu" ? "home" : "menu")} className="rounded-xl p-2.5" style={{ border: `1px solid ${palette.gold}44`, color: palette.offWhite }}>Menu</button></div>
        </div>
      </Container>
    </div>
  );
}

function Footer() {
  return (
    <footer className="mt-20 border-t border-[color:var(--gold-22)]/0 py-12" style={{ borderTop: `1px solid ${palette.gold}22`, background: `linear-gradient(180deg, #0B0B0C, #0A0A0B)` }}>
      <Container>
        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <div className="text-sm tracking-[0.22em]" style={{ color: palette.gray }}>APM LEGAL</div>
            <p className="mt-4 text-sm leading-relaxed" style={{ color: palette.offWhite }}>Boutique criminal defence & corporate litigation practice. Lucknow • Pan‑India.</p>
          </div>
          <div>
            <div className="text-sm tracking-[0.22em]" style={{ color: palette.gray }}>EXPERTISE</div>
            <ul className="mt-4 space-y-2 text-sm" style={{ color: palette.offWhite }}>
              <li>NDPS / PMLA</li><li>White‑Collar / Corporate</li><li>Commercial & Arbitration</li><li>High Court Practice</li>
            </ul>
          </div>
          <div>
            <div className="text-sm tracking-[0.22em]" style={{ color: palette.gray }}>CONTACT</div>
            <ul className="mt-4 space-y-2 text-sm" style={{ color: palette.offWhite }}>
              <li>Email: contact@example.com</li>
              <li>Phone: +91 00000 00000</li>
              <li>Lucknow, Uttar Pradesh</li>
            </ul>
          </div>
          <div>
            <div className="text-sm tracking-[0.22em]" style={{ color: palette.gray }}>POLICY</div>
            <ul className="mt-4 space-y-2 text-sm" style={{ color: palette.offWhite }}>
              <li><a href="#" className="hover:underline" onClick={(e)=>{e.preventDefault(); try{localStorage.removeItem('apm_terms_v1_accepted'); location.reload();}catch{}}}>View Terms / Reset Consent</a></li>
              <li><a href="#" className="hover:underline">Engagement Terms</a></li>
              <li><a href="#" className="hover:underline">Disclaimer</a></li>
              <li><a href="#" className="hover:underline">Make Payment</a></li>
            </ul>
          </div>
        </div>
        <div className="mt-12 text-xs" style={{ color: palette.gray }}>© {new Date().getFullYear()} APM Legal Services LLP. All rights reserved.</div>
      </Container>
    </footer>
  );
}

// -------------------------------------------------------------
// Root App
// -------------------------------------------------------------
export default function App() {
  const [route, setRoute] = useState("home");
  const [modalOpen, setModalOpen] = useState(false);
  const [modalItem, setModalItem] = useState(null);

  function navigate(r) { setRoute(r); window.scrollTo({ top: 0, behavior: "smooth" }); }
  function onQuickView(item) { setModalItem(item); setModalOpen(true); }

  useEffect(() => {
    const root = document.documentElement;
    root.style.setProperty("--bg", palette.black);
    root.style.setProperty("--gold", palette.gold);
    root.style.setProperty("--deepRed", palette.deepRed);
    root.style.setProperty("--offWhite", palette.offWhite);
  }, []);

  return (
    <div style={{ background: palette.black, fontFamily: fonts.body }} className="min-h-screen">
      <SEO />
      <TermsGate />
      <ScrollProgress />
      <CursorGlow />
      <Nav route={route} navigate={navigate} />

      <AnimatePresence mode="wait">
        <motion.main key={route} initial={{opacity:0, y:8}} animate={{opacity:1, y:0}} exit={{opacity:0, y:-8}} transition={{ duration: 0.6, ease: EASE }}>
          {route === "home" && (<Home navigate={navigate} onCTAClick={() => navigate("contact")} />)}
          {route === "engagements" && (<Engagements onQuickView={onQuickView} />)}
          {route === "team" && (<Team />)}
          {route === "contact" && (<Contact onSubmit={() => {}} />)}
          {route === "menu" && (
            <section className="py-16">
              <Container>
                <div className="flex flex-col gap-3">
                  {[["Home", "home"],["Practice Areas", "engagements"],["Team", "team"],["Contact", "contact"]].map(([label, k]) => (
                    <button key={k} onClick={() => navigate(k)} className="rounded-2xl px-6 py-4 text-left text-lg" style={{ border: `1px solid ${palette.gold}55`, color: palette.offWhite, background: 'rgba(255,255,255,0.06)' }}>{label}</button>
                  ))}
                </div>
              </Container>
            </section>
          )}
        </motion.main>
      </AnimatePresence>

      <Footer />

      {/* Floating Schedule CTA */}
      <div className="fixed bottom-5 right-5 z-40"><CTA label="Schedule a Consultation" onClick={() => setRoute('contact')} /></div>

      <Modal open={modalOpen} item={modalItem} onClose={() => setModalOpen(false)} onPrimary={() => { setModalOpen(false); setRoute("contact"); }} />
    </div>
  );
}

// -------------------------------------------------------------
// Lightweight diagnostics
// -------------------------------------------------------------
(function devTests(){
  try {
    // Existing tests
    console.assert(Array.isArray(heroImages) && heroImages.length >= 3, 'Hero images should exist');
    console.assert(engagementsDB.length >= 15, 'Should have at least 15 engagements');
    const cats = new Set(engagementsDB.map(e=>e.category));
    console.assert(categories.length === cats.size + 1, 'Categories derive from DB plus "All"');
    console.debug('[APM] Diagnostics OK'); // ensure no stray characters/comments here

    // Additional tests
    // 1) All engagement IDs are unique
    const ids = new Set(engagementsDB.map(e=>e.id));
    console.assert(ids.size === engagementsDB.length, 'Engagement IDs must be unique');
    // 2) Categories contain 'All' and all DB categories
    categories.forEach(c => console.assert(typeof c === 'string', 'Category should be string'));
    cats.forEach(c => console.assert(categories.includes(c), 'Categories must include all DB categories'));
    console.assert(categories[0] === 'All', 'First category should be "All"');
    // 3) Image paths sanity
    heroImages.forEach(p=>console.assert(typeof p === 'string' && p.startsWith('/assets/'), 'Hero image paths should start with /assets/'));
    engagementsDB.forEach(e=>console.assert(typeof e.image === 'string' && e.image.startsWith('/assets/'), 'Engagement image paths should start with /assets/'));
    // 4) Core components are functions
    console.assert(typeof App === 'function' && typeof Nav === 'function' && typeof Footer === 'function', 'Core components must exist');
  } catch (e) { console.warn('[APM] Diagnostics failed', e); }
})();
